package com.example.myfvouriteseries;

public class Series {
    private String name;
    private String language;
    private int numberOfSeasons;
    private int numberOfEpisodes;
    private double rating;
    private int poster;

    public Series(String name, String language, int numberOfSeasons, int numberOfEpisodes, double rating, int poster) {
        this.name = name;
        this.language = language;
        this.numberOfSeasons = numberOfSeasons;
        this.numberOfEpisodes = numberOfEpisodes;
        this.rating = rating;
        this.poster = poster;
    }

    public String getName() { return name; }

    public void setName(String name) { this.name = name; }

    public String getLanguage() { return language; }

    public void setLanguage(String language) { this.language = language; }

    public int getNumberOfSeasons() { return numberOfSeasons; }

    public void setNumberOfSeasons(int numberOfSeasons) {
        this.numberOfSeasons = numberOfSeasons;
    }

    public int getNumberOfEpisodes() { return numberOfEpisodes; }

    public void setNumberOfEpisodes(int numberOfEpisodes) {
        this.numberOfEpisodes = numberOfEpisodes;
    }

    public double getRating() { return rating; }

    public void setRating(double rating) { this.rating = rating; }

    public int getPoster() { return poster; }

    public void setPoster(int poster) { this.poster = poster; }
}
