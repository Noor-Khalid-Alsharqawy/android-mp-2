package com.example.myfvouriteseries;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SeriesAdapter extends RecyclerView.Adapter {

    ArrayList<Series> sArray;
    Context context;

    public SeriesAdapter(ArrayList<Series> sArray, Context context) {
        this.sArray = sArray;
        this.context = context;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //connects to series card
        View v= LayoutInflater.from(parent.getContext())
                .inflate(R.layout.series_card,parent,false);
        //does the same function of setContentView(R.layout.activity_main) in an activity.
        ViewHolder vh= new ViewHolder(v);
        return vh;//change null to the ViewHolder
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ((ViewHolder) holder).name.setText(sArray.get(position).getName());
        ((ViewHolder) holder).language.setText(sArray.get(position).getLanguage());
        ((ViewHolder) holder).episodes.setText(sArray.get(position).getNumberOfEpisodes()+"");
        ((ViewHolder) holder).seasons.setText(sArray.get(position).getNumberOfSeasons()+"");
        ((ViewHolder) holder).im.setImageResource(sArray.get(position).getPoster());
    }

    @Override
    public int getItemCount() {
        return sArray.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        public ImageView im;
        public TextView name;
        public TextView language;
        public TextView seasons;
        public TextView episodes;
        public View view;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //since this is not an activity we can't connect xml components to the above attributes
            //using findViewById(). the next 2 lines enable us to use findViewById() like if this
            //is an activity.
            view= itemView;//مهم جدًا
            im= itemView.findViewById(R.id.image);
            name= itemView.findViewById(R.id.textView);
            language= itemView.findViewById(R.id.textView3);
            seasons= itemView.findViewById(R.id.textView5);
            episodes= itemView.findViewById(R.id.textView7);

        }
    }
}
