package com.example.myfvouriteseries;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<Series> myList= new ArrayList<>();
        myList.add(new Series("Payitaht Abdülhamid","Turkish",
               5, 131, 4.5, R.drawable.payitaht_poster));
        myList.add(new Series("Mehmedçik", "Turkish",
                2, 33, 4.5, R.drawable.mehmedcik_poster));

        RecyclerView seriesList= findViewById(R.id.list);

        //this block يضبط تنسيق الريسيكل فيو (إيموجي وجه القمر)
        seriesList.setHasFixedSize(true);
        RecyclerView.LayoutManager lm = new LinearLayoutManager(this);
        seriesList.setLayoutManager(lm);

        SeriesAdapter sa= new SeriesAdapter(myList, MainActivity.this);
        seriesList.setAdapter(sa);

    }
}